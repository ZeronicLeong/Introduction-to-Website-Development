# Simple-Quiz-Website
A first project to learn the basics of HTML, CS, JavaScript, and PHP.
